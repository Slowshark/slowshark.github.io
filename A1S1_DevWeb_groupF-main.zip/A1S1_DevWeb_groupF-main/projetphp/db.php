<?php

$dsn = "mysql:host=localhost;dbname=db;port=8888"; 
$username = "root";
$password = "root";

$db = new PDO($dsn, $username, $password);

?>